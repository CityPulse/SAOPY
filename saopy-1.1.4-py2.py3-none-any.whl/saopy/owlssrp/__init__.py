import saopy.model

from saopy.model import owlssrp___ServiceParameter as ServiceParameter
