import saopy.model

from saopy.model import owlssp___Profile as Profile
