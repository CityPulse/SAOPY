import saopy.model

from saopy.model import ns1___DayOfWeek as DayOfWeek
from saopy.model import ns1___TemporalUnit as TemporalUnit
