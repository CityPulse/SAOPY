import saopy.model

from saopy.model import DUL___DesignedArtifact as DesignedArtifact
from saopy.model import DUL___Event as Event
from saopy.model import DUL___InformationEntity as InformationEntity
from saopy.model import DUL___InformationObject as InformationObject
from saopy.model import DUL___Method as Method
from saopy.model import DUL___Object as Object
from saopy.model import DUL___PhysicalObject as PhysicalObject
from saopy.model import DUL___Process as Process
from saopy.model import DUL___Quality as Quality
from saopy.model import DUL___Region as Region
from saopy.model import DUL___Situation as Situation
