import saopy.model

from saopy.model import rdfs___Bag as Bag
from saopy.model import rdfs___Class as Class
from saopy.model import rdfs___Resource as Resource
from saopy.model import rdfs___Seq as Seq
