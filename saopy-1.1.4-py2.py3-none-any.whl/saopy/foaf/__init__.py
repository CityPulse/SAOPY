import saopy.model

from saopy.model import foaf___Agent as Agent
from saopy.model import foaf___Document as Document
from saopy.model import foaf___Group as Group
from saopy.model import foaf___Image as Image
from saopy.model import foaf___OnlineAccount as OnlineAccount
from saopy.model import foaf___OnlineChatAccount as OnlineChatAccount
from saopy.model import foaf___OnlineEcommerceAccount as OnlineEcommerceAccount
from saopy.model import foaf___OnlineGamingAccount as OnlineGamingAccount
from saopy.model import foaf___Organization as Organization
from saopy.model import foaf___Person as Person
from saopy.model import foaf___PersonalProfileDocument as PersonalProfileDocument
from saopy.model import foaf___Project as Project
