import saopy.model

from saopy.model import owl___Thing as Thing
