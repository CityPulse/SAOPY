import saopy.model

from saopy.model import owlssc___ServiceCategory as ServiceCategory
