import saopy.model

from saopy.model import tzont___TimeZone as TimeZone
