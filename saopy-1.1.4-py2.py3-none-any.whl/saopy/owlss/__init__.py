import saopy.model

from saopy.model import owlss___Service as Service
