import saopy.model

from saopy.model import geo___SpatialThing as SpatialThing
